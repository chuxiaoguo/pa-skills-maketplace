---
title: Rule Title Here
impact: MEDIUM
impactDescription: brief description of impact
tags: composition, components
---

## Rule Title Here

Brief explanation of the rule and why it matters.

**Incorrect:**

```tsx
// Bad code example
```

**Correct:**

```tsx
// Good code example
```

Reference: [Link](https://example.com)
